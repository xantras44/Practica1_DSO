# UC3M LaTeX template for work report
I have created two template in LaTeX, one I use on all my work reports on the University and one I use for all my expositions and defenses. Those use the Corporative Identity (logos, fonts, and colors) of my University, Universidad Carlos III de Madrid. These logos are property of Universidad Carlos III de Madrid and are behind their own use policy and legal restrictions.

**Feel free** of use it on your works at the UC3M. If someone asks you about the template or you see people who like it, don't forget to tell them you got it from here ;)

NOTE: For a reason I don't know, the title slide doesn't render in GitHub PDF preview, but you can check it if you download the sample PDF.

This template is licensed under [MIT license](https://github.com/tairosonloa/UC3M_LaTeX_template/blob/master/LICENSE).

# Plantilla en LaTeX para memorias UC3M
He creado dos plantilla en LaTeX que uso para todos mis trabajos y memorias en la universidad así como para mis exposiciones y defensas. Estas plantillas usan la identidad corporativa (logos, fuentes y colores) de mi universidad, Universidad Carlos III de Madrid. Estos logos son propiedad de la Universidad Carlos III de Madrid y están bajo su propia política de uso y restricciones legales.

**Siéntete libre** de usarla en tus trabajos en la UC3M. Si te preguntan por la plantilla o les gusta, no olvides comentarles que la has sacado de aquí ;)

NOTA: Por alguna razón que desconozco, la diapositiva de título no se muestra en la vista previa del PDF desde GitHub, pero se puede comprobar si se descarga el PDF de prueba.

Esta plantilla esta bajo [licencia MIT](https://github.com/tairosonloa/UC3M_LaTeX_template/blob/master/LICENSE).
